from pathlib import Path
import json, wave
R=Path(__file__).resolve().parent
paragraphs=json.loads((R/'paragraph-marks.json').read_text(encoding='utf-8-sig'))
sentences=json.loads((R/'sentences.json').read_text(encoding='utf-8'))
records=[]; duration=0
for paragraph in paragraphs:
    section=paragraph['section']; rows=[r for r in sentences if r['section']==section]
    with wave.open(str(R/'paragraphs'/f'{section}.wav')) as w:
        params=w.getparams(); raw=w.readframes(w.getnframes()); frames=w.getnframes()
    seconds=frames/params.framerate; duration+=seconds
    starts=[]; char_starts=[]; offset=0
    for row in rows:
        text=row['spoken'].replace('\u2019',"'")
        assert paragraph['spoken'][offset:offset+len(text)]==text
        marks=[m for m in paragraph['marks'] if offset<=m['start']<offset+len(text)]
        assert marks, row['id']
        starts.append(round(marks[0]['seconds']*params.framerate));char_starts.append(offset)
        offset+=len(text)+1
    starts[0]=0; ends=starts[1:]+[frames]
    stride=params.sampwidth*params.nchannels
    for i,(row,a,b) in enumerate(zip(rows,starts,ends)):
        assert b>a
        with wave.open(str(R/'audio'/f"{row['id']:02}.wav"),'wb') as w:
            w.setparams(params);w.writeframes(raw[a*stride:b*stride])
        char_end=char_starts[i+1] if i+1<len(rows) else len(paragraph['spoken'])
        marks=[{**m,'seconds':m['seconds']-a/params.framerate,'start':m['start']-char_starts[i]}
               for m in paragraph['marks'] if char_starts[i]<=m['start']<char_end]
        records.append({**row,'voice':'Microsoft Zira Desktop','rate':-1,'synthesis':'continuous paragraph; lossless PCM split for editing','marks':marks})
    print(section,round(seconds,3))
assert len(records)==35
assert duration+1.5<175, duration
(R/'speech-marks.json').write_text(json.dumps(records,ensure_ascii=False,indent=2),encoding='utf-8')
print('Total continuous narration seconds:',duration)
