﻿$ErrorActionPreference = 'Stop'
$outputDirectory = $PSScriptRoot
Add-Type -AssemblyName System.Speech
Add-Type -ReferencedAssemblies System.Speech -TypeDefinition @"
using System;
using System.Collections.Generic;
using System.Speech.Synthesis;
using System.Speech.AudioFormat;
public class WordMark {public double seconds; public int start; public int count; public string text;}
public static class LocalParagraph {
 public static WordMark[] Render(string text,string path) {
  var marks=new List<WordMark>();
  using(var synth=new SpeechSynthesizer()) {
   synth.SelectVoice("Microsoft Zira Desktop"); synth.Rate=-1; synth.Volume=100;
   synth.SpeakProgress += (o,e) => marks.Add(new WordMark {seconds=e.AudioPosition.TotalSeconds,start=e.CharacterPosition,count=e.CharacterCount,text=e.Text});
   synth.SetOutputToWaveFile(path,new SpeechAudioFormatInfo(16000,AudioBitsPerSample.Sixteen,AudioChannel.Mono)); synth.Speak(text); synth.SetOutputToNull();
  }
  return marks.ToArray();
 }
}
"@
$sentences = Get-Content -Raw -Encoding UTF8 (Join-Path $outputDirectory 'sentences.json') | ConvertFrom-Json
$records=@()
foreach ($section in @('A','B','C','D','E','F')) {
 $rows=@($sentences | Where-Object { $_.section -eq $section })
 $spoken=($rows.spoken -join ' ').Replace([char]0x2019, [char]39)
 $marks=[LocalParagraph]::Render($spoken,(Join-Path $outputDirectory ('paragraphs\'+$section+'.wav')))
 $records += [pscustomobject]@{section=$section; spoken=$spoken; rate=-1; voice='Microsoft Zira Desktop'; marks=@($marks)}
}
$records | ConvertTo-Json -Depth 6 | Set-Content -Encoding UTF8 (Join-Path $outputDirectory 'paragraph-marks.json')
Write-Output ('Synthesized '+$records.Count+' continuous paragraphs with local Zira')
