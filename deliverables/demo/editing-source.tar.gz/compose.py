﻿
"""Rebuild the local AI-narrated candidate from preserved genuine browser captures.
No network requests, app changes, model runs, API calls or publication.
Run with the project's .venv Python from any working directory.
"""
from pathlib import Path
import csv, hashlib, json, math, subprocess, textwrap, wave
from collections import defaultdict
from PIL import Image, ImageDraw, ImageFont

ROOT=Path(__file__).resolve().parent
REPO=ROOT.parents[1]
CAP=ROOT/"capture/session"
DURATION=175.0
INTRO=1.5
FONT=Path("C:/Windows/Fonts/arial.ttf")
BOLD=Path("C:/Windows/Fonts/arialbd.ttf")
frames_dir=ROOT/"edited_frames"
frames_dir.mkdir(exist_ok=True)

def font(size,bold=False):
    return ImageFont.truetype(str(BOLD if bold else FONT),size)
def tstamp(t,ass=False):
    units=round(t*(100 if ass else 1000))
    scale=100 if ass else 1000
    h,rem=divmod(units,3600*scale); m,rem=divmod(rem,60*scale); s,ms=divmod(rem,scale)
    return f"{h}:{m:02}:{s:02}.{ms:02}" if ass else f"{h:02}:{m:02}:{s:02},{ms:03}"
def dump(path,value):
    path.write_text(json.dumps(value,ensure_ascii=False,indent=2),encoding="utf-8")

speech=json.loads((ROOT/"speech-marks.json").read_text(encoding="utf-8-sig"))
timeline=[]
pcm=bytearray()
params=None
for r in speech:
    with wave.open(str(ROOT/"audio"/f"{r['id']:02}.wav")) as w:
        if params is None:
            params=w.getparams()
            pcm.extend(b"\0"*round(INTRO*params.framerate)*params.sampwidth*params.nchannels)
        assert (w.getnchannels(),w.getsampwidth(),w.getframerate())==(params.nchannels,params.sampwidth,params.framerate)
        start=len(pcm)/(params.framerate*params.sampwidth*params.nchannels)
        pcm.extend(w.readframes(w.getnframes()))
        end=len(pcm)/(params.framerate*params.sampwidth*params.nchannels)
        timeline.append({**r,"start":start,"end":end})
byte_total=round(DURATION*params.framerate)*params.sampwidth*params.nchannels
assert len(pcm)<byte_total, "Narration exceeds video length"
pcm.extend(b"\0"*(byte_total-len(pcm)))
with wave.open(str(ROOT/"narration.wav"),"wb") as w:
    w.setparams(params); w.writeframes(pcm)
dump(ROOT/"narration-timeline.json",timeline)
sections={s:{"start":min(r["start"] for r in timeline if r["section"]==s),
             "end":max(r["end"] for r in timeline if r["section"]==s)} for s in "ABCDEF"}

# Whole-sentence captions: start at first measured spoken word, end after the
# final spoken sentence. No proportional word timings or ASR guesses are used.
srt=[]; ass=[]
for i,r in enumerate(timeline,1):
    marks=r["marks"]
    begin=r["start"]+(marks[0]["seconds"] if marks else 0)
    end=r["end"]-0.05
    assert begin<end
    lines=textwrap.wrap(r["display"],width=92,break_long_words=False,break_on_hyphens=False)
    assert len(lines)<=3, (r["display"],lines)
    srt.extend([str(i),f"{tstamp(begin)} --> {tstamp(end)}","\n".join(lines),""])
    caption=r"\N".join(lines).replace("{","(").replace("}",")")
    ass.append(f"Dialogue: 0,{tstamp(begin,True)},{tstamp(end,True)},Narration,,0,0,0,,{caption}")
(ROOT/"bluebikes_demo_en.srt").write_text("\n".join(srt),encoding="utf-8")
ass_header="""[Script Info]
ScriptType: v4.00+
PlayResX: 1920
PlayResY: 1080
WrapStyle: 2

[V4+ Styles]
Format: Name, Fontname, Fontsize, PrimaryColour, SecondaryColour, OutlineColour, BackColour, Bold, Italic, Underline, StrikeOut, ScaleX, ScaleY, Spacing, Angle, BorderStyle, Outline, Shadow, Alignment, MarginL, MarginR, MarginV, Encoding
Style: Narration,Arial,32,&H00FFFFFF,&H00FFFFFF,&H00101010,&H00000000,0,0,0,0,100,100,0,0,1,1,0,2,65,65,20,1

[Events]
Format: Layer, Start, End, Style, Name, MarginL, MarginR, MarginV, Effect, Text
"""
(ROOT/"captions.ass").write_text(ass_header+"\n".join(ass)+"\n",encoding="utf-8")

with (REPO/"results/focused_event_chain.csv").open(encoding="utf-8") as f:
    focused=next(r for r in csv.DictReader(f) if float(r["event_increment_handling_actions"])>0)
ft0=int(float(focused["full_time_base"]));ft1=int(float(focused["full_time_scenario"]))
cost0=float(focused["crew_cost_base"]); cost1=float(focused["crew_cost_scenario"])
delta=f"Boston / April: +{ft1-ft0} crew / +{chr(36)}{cost1-cost0:,.0f}"
assert (ft0,ft1,cost0,cost1)==(12,13,72000,78000)

chapters={"A":"1 / The decision","B":"2 / AI + analytics","C":"3 / Review the event",
          "D":"4 / Confirm, then Apply","E":delta,"F":"6 / Evidence and limits"}
def edit_frame(name,section):
    target=frames_dir/f"{name}-{section}.png"
    if name=="closing":
        canvas=Image.new("RGB",(1920,1080),"#101720")
        dr=ImageDraw.Draw(canvas)
        dr.text((90,120),"From reviewed text to a hiring decision",font=font(55,True),fill="#ffffff")
        dr.text((90,205),"Preserve the failures. Keep the human gate. Make the decision explicit.",
                font=font(32),fill="#c8d6e4")
        cards=[
            ("EVIDENCE PRESERVED",["Unsupported dates and participant counts remain visible.",
                                   "All three supplemental cases are excluded from staffing plans."]),
            ("CONFIRMED CONTRIBUTIONS",["Satoshi: seven event reviews; eight conditional assumption decisions.",
                                        "Vinay: README / English UI review and usability improvements.",
                                        "Aditi: contribution not yet confirmed."]),
            ("LIMITS OF THIS DEMO",["Uncalibrated retrospective scenario; no demonstrated event effect.",
                                    "Monthly proxy capacity does not guarantee station-hour service.",
                                    "Estimated uncovered work is not measured lost trips."])
        ]
        y=290
        for title,lines in cards:
            height=110+len(lines)*34
            dr.rounded_rectangle((82,y,1838,y+height),radius=14,fill="#1b2836")
            dr.text((106,y+18),title,font=font(24,True),fill="#79d6cb")
            for j,line in enumerate(lines):
                dr.text((106,y+58+j*34),line,font=font(28),fill="#f2f5f8")
            y+=height+20
    else:
        im=Image.open(CAP/(name+".jpg")).convert("RGB")
        assert im.size==(1425,713),im.size
        canvas=Image.new("RGB",(1920,1080),"#101720")
        im=im.resize((1800,900),Image.Resampling.LANCZOS)
        canvas.paste(im,(60,56))
        dr=ImageDraw.Draw(canvas)
    dr.rectangle((0,0,1920,55),fill="#142d36")
    dr.text((38,14),"AI-generated narration  |  Saved real OpenAI response",font=font(23,True),fill="#f7ffff")
    label=chapters[section]
    width=dr.textlength(label,font=font(23,True))
    dr.text((1880-width,14),label,font=font(23,True),fill="#9af0d8")
    dr.rectangle((0,956,1920,1080),fill="#101720")
    canvas.save(target,optimize=True)
    return target

# Genuine UI frames are held for explanation. Only the recorded operation
# segments retain wall-clock frame intervals; these are not synthesized UI.
edits=[]
def hold(name,section,start,end,kind="held genuine app frame"):
    assert end>start,(name,start,end)
    edits.append({"name":name,"section":section,"start":start,"end":end,"kind":kind})
def sequence(filename,section,start,end):
    rows=json.loads((CAP/filename).read_text(encoding="utf-8"))
    origin=rows[0]["elapsed"]
    for i,row in enumerate(rows):
        local=row["elapsed"]-origin
        next_local=rows[i+1]["elapsed"]-origin if i+1<len(rows) else end-start
        a=start+local; b=min(start+next_local,end)
        if a<end and b>a: hold(row["name"],section,a,b,"recorded UI action at original speed")
hold("A_intro","A",0,sections["A"]["end"])
hold("B_architecture","B",sections["B"]["start"],sections["B"]["end"])
hold("C_source","C",sections["C"]["start"],sections["C"]["end"])
d0=sections["D"]["start"]
sequence("D_frames.json","D",d0,d0+22)
units_start=next(r["start"] for r in timeline if r["display"].startswith("Our base conversion"))
hold("D_result","D",d0+22,units_start)
hold("D_units","D",units_start,sections["D"]["end"])
e0=sections["E"]["start"];e1=sections["E"]["end"]
hold("E_geography","E",e0,e1-5)
sequence("E_frames.json","E",e1-5,e1)
f0=sections["F"]["start"]
close_start=next(r["start"] for r in timeline if r["display"].startswith("Our strongest feature"))
hold("F_evaluation","F",f0,close_start)
hold("closing","F",close_start,DURATION,"editorial closing card; not an app screen")
# Tiny capture offset differences are normalized only within sub-frame precision.
for prev,nxt in zip(edits,edits[1:]):
    assert abs(prev["end"]-nxt["start"])<0.02,(prev,nxt)
    prev["end"]=nxt["start"]
dump(ROOT/"edit-decision-list.json",edits)
concat=["ffconcat version 1.0"]
for shot in edits:
    p=edit_frame(shot["name"],shot["section"])
    concat += [f"file '{p.relative_to(ROOT).as_posix()}'",f"duration {shot['end']-shot['start']:.9f}"]
concat.append(f"file '{p.relative_to(ROOT).as_posix()}'")
(ROOT/"frames.ffconcat").write_text("\n".join(concat)+"\n",encoding="utf-8")

script=["# AI-narrated submission candidate — final production script","",
        "Base commit: c9583c809bf0c7add65239ceb6d4be981ab10fc2.",
        "Local Microsoft Zira Desktop, rate -1; continuous paragraph synthesis. AI-generated narration, not a human presenter.",
        "Saved real OpenAI responses only; no new extraction API call.",
        "The original 307-word narration is preserved. Pronunciation-only expansions are in sentences.json.",
        "Edited real app captures include held frames; Confirm/Apply and the map scroll run at recorded speed.",
        "Human narrator/operator agreement is not claimed.",""]
for s in "ABCDEF":
    script += [f"## {tstamp(sections[s]['start'])}–{tstamp(sections[s]['end'])} · {s}",""]
    script += [" ".join(r["display"] for r in timeline if r["section"]==s),""]
script += ["## Production disclosures","",
           "Synthetic narration is a video production tool, not an additional course technique.",
           "The three demonstrated techniques remain API calls, prompt engineering and structured output.",
           "Target/render duration includes a 1.5-second opening and the final still frame.",
           "Audio listening quality and final team approval remain human review tasks."]
(ROOT/"FINAL_SCRIPT.md").write_text("\n".join(script)+"\n",encoding="utf-8")
summary={"base_commit":"c9583c809bf0c7add65239ceb6d4be981ab10fc2","voice":"Microsoft Zira Desktop",
         "rate":-1,"synthesis":"continuous paragraphs; measured sentence boundaries", "written_words":307,"narration_source_seconds":sum(r["end"]-r["start"] for r in timeline),
         "opening_seconds":INTRO,"planned_output_seconds":DURATION,"sections":sections,
         "caption_count":len(timeline),"requested_browser_viewport":[1440,720],"captured_pixels":[1425,713],"output_pixels":[1920,1080],
         "screen_presentation":"Real browser captures scaled to 1800x900; separate top disclosure and bottom captions",
         "continuous_live_take":False,"app_source_unchanged":True,"new_openai_calls":0}
dump(ROOT/"production-manifest.json",summary)
print(json.dumps(summary,indent=2))
cmd=["ffmpeg","-hide_banner","-y","-f","concat","-safe","0","-i","frames.ffconcat",
     "-i","narration.wav","-i","bluebikes_demo_en.srt","-map","0:v:0","-map","1:a:0","-map","2:0",
     "-vf","fps=25,subtitles=captions.ass","-c:v","libx264","-preset","medium","-crf","18",
     "-pix_fmt","yuv420p","-c:a","aac","-b:a","192k","-af","loudnorm=I=-18:TP=-2:LRA=7",
     "-c:s","mov_text","-metadata:s:s:0","language=eng","-metadata",
     "title=Bluebikes - AI-narrated submission candidate","-t",str(DURATION),
     "-movflags","+faststart","bluebikes_demo_candidate.mp4"]
(ROOT/"ffmpeg-command.json").write_text(json.dumps(cmd,indent=2),encoding="utf-8")
with (ROOT/"encode.log").open("w",encoding="utf-8") as log:
    subprocess.run(cmd,cwd=ROOT,stdout=log,stderr=log,check=True)
print("Rendered",ROOT/"bluebikes_demo_candidate.mp4")

